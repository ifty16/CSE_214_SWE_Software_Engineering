

public interface MicroController {
    Controller getController(); 
    Storage getStorage();
    Ticketing getTicketing();
    String getMicroController();

    
}

class ATMega32 implements MicroController {

    @Override
    public String getMicroController() {
        return "ATMega32";
    }
    @Override 
    public Controller getController(){
        return new Separate();
    }
    @Override 
    public Storage getStorage(){
        return new SDcard();
    }

    @Override
    public Ticketing getTicketing(){
        return new RFID();
    }
}

class ArduinoMega implements MicroController {

    @Override
    public String getMicroController() {
        return "Arduino Mega";
    }

    @Override 
    public Controller getController(){
        return new Separate();
    }
    @Override 
    public Storage getStorage(){
        return new SDcard();
    }
    @Override
    public Ticketing getTicketing(){
        return new RFID();
    }
}

class RaspberryPi implements MicroController {

    @Override
    public String getMicroController() {
        return "Raspberry Pi";
    }
    @Override 
    public Controller getController(){
        return new BuiltIn();
    }
    
    @Override 
    public Storage getStorage(){
        return new Free();
    }
    @Override
    public Ticketing getTicketing(){
        return new NFC();
    }
}


public interface Display {

    String getDisplay();
}

class OLED implements Display {

    @Override
    public String getDisplay() {
        return "OLED Display";
    }

}

class TouchScreen implements Display {

    @Override
    public String getDisplay() {
        return "Touch Screen Display";
    }

}

class LCD implements Display {

    @Override
    public String getDisplay() {
        return "LCD Display";
    }

}
class LED implements Display {

    @Override
    public String getDisplay() {
        return "LED Display";
    }

}

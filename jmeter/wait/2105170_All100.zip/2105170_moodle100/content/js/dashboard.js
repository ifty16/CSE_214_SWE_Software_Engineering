/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 94.6086956521739, "KoPercent": 5.391304347826087};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9460869565217391, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "Moodle/moodle/course/view.php-314-2"], "isController": false}, {"data": [1.0, 500, 1500, "Moodle/moodle/course/view.php-314-1"], "isController": false}, {"data": [1.0, 500, 1500, "Moodle/moodle/h5p/h5plib/v124/joubel/core/js/h5p-resizer.js-318"], "isController": false}, {"data": [0.98, 500, 1500, "Moodle/moodle/mod/forum/view.php-312"], "isController": false}, {"data": [0.99, 500, 1500, "Moodle/moodle/course/view.php-311"], "isController": false}, {"data": [1.0, 500, 1500, "Moodle/moodle/theme/image.php/classic/folder/1731384351/monologo-313"], "isController": false}, {"data": [0.0, 500, 1500, "Moodle/moodle/-319"], "isController": false}, {"data": [0.98, 500, 1500, "Moodle/moodle/course/view.php-310"], "isController": false}, {"data": [1.0, 500, 1500, "Moodle/moodle/calendar/view.php-320"], "isController": false}, {"data": [0.88, 500, 1500, "Moodle/moodle/my/-307"], "isController": false}, {"data": [1.0, 500, 1500, "Moodle/moodle/mod/forum/view.php-312-2"], "isController": false}, {"data": [1.0, 500, 1500, "Moodle/moodle/mod/forum/view.php-312-0"], "isController": false}, {"data": [1.0, 500, 1500, "Moodle/moodle/mod/forum/post.php-317"], "isController": false}, {"data": [1.0, 500, 1500, "Moodle/moodle/mod/forum/view.php-312-1"], "isController": false}, {"data": [1.0, 500, 1500, "Moodle/moodle/course/view.php-314"], "isController": false}, {"data": [1.0, 500, 1500, "Moodle/moodle/course/view.php-310-0"], "isController": false}, {"data": [1.0, 500, 1500, "Moodle/moodle/course/view.php-310-2"], "isController": false}, {"data": [1.0, 500, 1500, "Moodle/moodle/course/view.php-311-1"], "isController": false}, {"data": [0.93, 500, 1500, "Moodle/moodle/user/profile.php-305"], "isController": false}, {"data": [1.0, 500, 1500, "Moodle/moodle/course/view.php-310-1"], "isController": false}, {"data": [1.0, 500, 1500, "Moodle/moodle/course/view.php-311-0"], "isController": false}, {"data": [1.0, 500, 1500, "Moodle/moodle/course/view.php-314-0"], "isController": false}, {"data": [1.0, 500, 1500, "Moodle/moodle/course/view.php-311-2"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 2300, 124, 5.391304347826087, 44.19391304347821, 3, 2661, 28.0, 81.90000000000009, 108.0, 131.0, 23.081245985870265, 135.0861673716482, 16.389723075224794], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Moodle/moodle/course/view.php-314-2", 100, 0, 0.0, 26.63, 22, 37, 26.0, 31.0, 33.0, 37.0, 1.010152027880196, 6.600120271225819, 0.5346703116319006], "isController": false}, {"data": ["Moodle/moodle/course/view.php-314-1", 100, 0, 0.0, 13.92, 10, 38, 13.0, 17.900000000000006, 20.94999999999999, 37.909999999999954, 1.010243872870911, 1.982998227022003, 0.5406383225910735], "isController": false}, {"data": ["Moodle/moodle/h5p/h5plib/v124/joubel/core/js/h5p-resizer.js-318", 100, 0, 0.0, 6.240000000000001, 3, 46, 5.0, 8.0, 9.0, 45.87999999999994, 1.0103969849753969, 1.5807187206353375, 0.43810181770417594], "isController": false}, {"data": ["Moodle/moodle/mod/forum/view.php-312", 100, 2, 2.0, 68.61000000000003, 56, 164, 65.0, 78.80000000000001, 94.89999999999998, 163.40999999999968, 1.009805208575266, 10.649983606443568, 1.60937705116683], "isController": false}, {"data": ["Moodle/moodle/course/view.php-311", 100, 1, 1.0, 64.75, 54, 105, 63.0, 71.9, 83.94999999999999, 104.87999999999994, 1.0099377878322695, 10.651904584865072, 1.6066295472448897], "isController": false}, {"data": ["Moodle/moodle/theme/image.php/classic/folder/1731384351/monologo-313", 100, 0, 0.0, 6.109999999999999, 3, 17, 5.0, 9.0, 10.0, 16.97999999999999, 1.0103561505430665, 0.991609307906037, 0.5219515660520334], "isController": false}, {"data": ["Moodle/moodle/-319", 100, 100, 100.0, 128.55, 121, 171, 127.0, 137.60000000000002, 139.89999999999998, 170.86999999999995, 1.0091835704914724, 11.905646066707034, 0.5331721793319204], "isController": false}, {"data": ["Moodle/moodle/course/view.php-310", 100, 2, 2.0, 68.83000000000004, 55, 110, 68.0, 75.9, 81.94999999999999, 109.93999999999997, 1.0100193923723337, 10.6527356848689, 1.6067593654048158], "isController": false}, {"data": ["Moodle/moodle/calendar/view.php-320", 100, 0, 0.0, 47.0, 39, 81, 46.0, 52.0, 53.0, 80.99, 1.0101010101010102, 8.231948390151516, 0.5376025883838383], "isController": false}, {"data": ["Moodle/moodle/my/-307", 100, 12, 12.0, 94.02999999999999, 80, 120, 92.0, 105.60000000000002, 109.89999999999998, 119.94999999999997, 1.0097746183051943, 13.893700000378667, 0.5236233616406818], "isController": false}, {"data": ["Moodle/moodle/mod/forum/view.php-312-2", 100, 0, 0.0, 26.409999999999997, 20, 66, 25.0, 30.0, 33.94999999999999, 65.88999999999994, 1.010192845814266, 6.600475753477589, 0.5317323670838763], "isController": false}, {"data": ["Moodle/moodle/mod/forum/view.php-312-0", 100, 0, 0.0, 27.21, 19, 62, 25.0, 32.900000000000006, 37.849999999999966, 61.889999999999944, 1.0102234614296683, 2.0707607866610096, 0.5406273992807209], "isController": false}, {"data": ["Moodle/moodle/mod/forum/post.php-317", 100, 0, 0.0, 47.32, 39, 60, 46.0, 52.0, 56.799999999999955, 59.989999999999995, 1.0099785884539247, 7.390409827217913, 0.5483868116995919], "isController": false}, {"data": ["Moodle/moodle/mod/forum/view.php-312-1", 100, 0, 0.0, 14.849999999999996, 10, 65, 14.0, 18.0, 21.94999999999999, 64.73999999999987, 1.0102949050827938, 1.9830983976722807, 0.537705784443479], "isController": false}, {"data": ["Moodle/moodle/course/view.php-314", 100, 0, 0.0, 65.77000000000004, 52, 94, 65.0, 75.80000000000001, 79.94999999999999, 93.91999999999996, 1.0097746183051943, 10.649572234227321, 1.6152449460780354], "isController": false}, {"data": ["Moodle/moodle/course/view.php-310-0", 100, 0, 0.0, 26.140000000000004, 20, 46, 26.0, 30.0, 31.0, 45.91999999999996, 1.010468453174892, 2.0712629718887676, 0.5377981513479649], "isController": false}, {"data": ["Moodle/moodle/course/view.php-310-2", 100, 0, 0.0, 28.179999999999993, 22, 43, 28.0, 32.0, 33.0, 42.989999999999995, 1.0103561505430665, 6.602036104445568, 0.5318183253346805], "isController": false}, {"data": ["Moodle/moodle/course/view.php-311-1", 100, 0, 0.0, 14.100000000000001, 10, 47, 13.0, 17.900000000000006, 18.94999999999999, 46.8099999999999, 1.0103867760578749, 1.9832787303479773, 0.5377546806167401], "isController": false}, {"data": ["Moodle/moodle/user/profile.php-305", 100, 7, 7.0, 151.6899999999999, 49, 2661, 61.0, 81.80000000000001, 378.2999999999969, 2658.1999999999985, 1.0095095802459164, 6.730215031850027, 0.5146132821175473], "isController": false}, {"data": ["Moodle/moodle/course/view.php-310-1", 100, 0, 0.0, 14.39, 11, 39, 14.0, 18.0, 20.0, 38.87999999999994, 1.0105501434981203, 1.9835994027648651, 0.5378416291078864], "isController": false}, {"data": ["Moodle/moodle/course/view.php-311-0", 100, 0, 0.0, 24.470000000000006, 18, 44, 23.0, 28.900000000000006, 29.94999999999999, 43.95999999999998, 1.0103357345645958, 2.0709909246592644, 0.5377275149782272], "isController": false}, {"data": ["Moodle/moodle/course/view.php-314-0", 100, 0, 0.0, 25.140000000000004, 19, 38, 24.5, 30.0, 31.0, 37.95999999999998, 1.0101622320544679, 2.070635278400711, 0.5405946319978988], "isController": false}, {"data": ["Moodle/moodle/course/view.php-311-2", 100, 0, 0.0, 26.119999999999997, 20, 50, 25.0, 30.900000000000006, 36.89999999999998, 49.95999999999998, 1.0102846982279607, 6.601598807106343, 0.5317807151805379], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["The operation lasted too long: It took 140 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.8064516129032258, 0.043478260869565216], "isController": false}, {"data": ["The operation lasted too long: It took 118 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.8064516129032258, 0.043478260869565216], "isController": false}, {"data": ["The operation lasted too long: It took 115 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.8064516129032258, 0.043478260869565216], "isController": false}, {"data": ["The operation lasted too long: It took 122 milliseconds, but should not have lasted longer than 100 milliseconds.", 9, 7.258064516129032, 0.391304347826087], "isController": false}, {"data": ["The operation lasted too long: It took 164 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.8064516129032258, 0.043478260869565216], "isController": false}, {"data": ["The operation lasted too long: It took 129 milliseconds, but should not have lasted longer than 100 milliseconds.", 9, 7.258064516129032, 0.391304347826087], "isController": false}, {"data": ["The operation lasted too long: It took 147 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.8064516129032258, 0.043478260869565216], "isController": false}, {"data": ["The operation lasted too long: It took 126 milliseconds, but should not have lasted longer than 100 milliseconds.", 9, 7.258064516129032, 0.391304347826087], "isController": false}, {"data": ["The operation lasted too long: It took 123 milliseconds, but should not have lasted longer than 100 milliseconds.", 8, 6.451612903225806, 0.34782608695652173], "isController": false}, {"data": ["The operation lasted too long: It took 114 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.8064516129032258, 0.043478260869565216], "isController": false}, {"data": ["The operation lasted too long: It took 2,381 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.8064516129032258, 0.043478260869565216], "isController": false}, {"data": ["The operation lasted too long: It took 125 milliseconds, but should not have lasted longer than 100 milliseconds.", 10, 8.064516129032258, 0.43478260869565216], "isController": false}, {"data": ["The operation lasted too long: It took 392 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.8064516129032258, 0.043478260869565216], "isController": false}, {"data": ["The operation lasted too long: It took 133 milliseconds, but should not have lasted longer than 100 milliseconds.", 4, 3.225806451612903, 0.17391304347826086], "isController": false}, {"data": ["The operation lasted too long: It took 128 milliseconds, but should not have lasted longer than 100 milliseconds.", 9, 7.258064516129032, 0.391304347826087], "isController": false}, {"data": ["The operation lasted too long: It took 1,381 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.8064516129032258, 0.043478260869565216], "isController": false}, {"data": ["The operation lasted too long: It took 104 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.8064516129032258, 0.043478260869565216], "isController": false}, {"data": ["The operation lasted too long: It took 130 milliseconds, but should not have lasted longer than 100 milliseconds.", 8, 6.451612903225806, 0.34782608695652173], "isController": false}, {"data": ["The operation lasted too long: It took 148 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.8064516129032258, 0.043478260869565216], "isController": false}, {"data": ["The operation lasted too long: It took 106 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, 2.4193548387096775, 0.13043478260869565], "isController": false}, {"data": ["The operation lasted too long: It took 131 milliseconds, but should not have lasted longer than 100 milliseconds.", 5, 4.032258064516129, 0.21739130434782608], "isController": false}, {"data": ["The operation lasted too long: It took 124 milliseconds, but should not have lasted longer than 100 milliseconds.", 8, 6.451612903225806, 0.34782608695652173], "isController": false}, {"data": ["The operation lasted too long: It took 110 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 1.6129032258064515, 0.08695652173913043], "isController": false}, {"data": ["The operation lasted too long: It took 127 milliseconds, but should not have lasted longer than 100 milliseconds.", 8, 6.451612903225806, 0.34782608695652173], "isController": false}, {"data": ["The operation lasted too long: It took 134 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.8064516129032258, 0.043478260869565216], "isController": false}, {"data": ["The operation lasted too long: It took 2,661 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.8064516129032258, 0.043478260869565216], "isController": false}, {"data": ["The operation lasted too long: It took 120 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.8064516129032258, 0.043478260869565216], "isController": false}, {"data": ["The operation lasted too long: It took 138 milliseconds, but should not have lasted longer than 100 milliseconds.", 5, 4.032258064516129, 0.21739130434782608], "isController": false}, {"data": ["The operation lasted too long: It took 105 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 1.6129032258064515, 0.08695652173913043], "isController": false}, {"data": ["The operation lasted too long: It took 171 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.8064516129032258, 0.043478260869565216], "isController": false}, {"data": ["The operation lasted too long: It took 102 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 1.6129032258064515, 0.08695652173913043], "isController": false}, {"data": ["The operation lasted too long: It took 132 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.8064516129032258, 0.043478260869565216], "isController": false}, {"data": ["The operation lasted too long: It took 108 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, 2.4193548387096775, 0.13043478260869565], "isController": false}, {"data": ["The operation lasted too long: It took 158 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.8064516129032258, 0.043478260869565216], "isController": false}, {"data": ["The operation lasted too long: It took 121 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.8064516129032258, 0.043478260869565216], "isController": false}, {"data": ["The operation lasted too long: It took 113 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.8064516129032258, 0.043478260869565216], "isController": false}, {"data": ["The operation lasted too long: It took 2,309 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.8064516129032258, 0.043478260869565216], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 2300, 124, "The operation lasted too long: It took 125 milliseconds, but should not have lasted longer than 100 milliseconds.", 10, "The operation lasted too long: It took 122 milliseconds, but should not have lasted longer than 100 milliseconds.", 9, "The operation lasted too long: It took 129 milliseconds, but should not have lasted longer than 100 milliseconds.", 9, "The operation lasted too long: It took 126 milliseconds, but should not have lasted longer than 100 milliseconds.", 9, "The operation lasted too long: It took 128 milliseconds, but should not have lasted longer than 100 milliseconds.", 9], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Moodle/moodle/mod/forum/view.php-312", 100, 2, "The operation lasted too long: It took 105 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, "The operation lasted too long: It took 164 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, "", "", "", "", "", ""], "isController": false}, {"data": ["Moodle/moodle/course/view.php-311", 100, 1, "The operation lasted too long: It took 105 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["Moodle/moodle/-319", 100, 100, "The operation lasted too long: It took 125 milliseconds, but should not have lasted longer than 100 milliseconds.", 10, "The operation lasted too long: It took 122 milliseconds, but should not have lasted longer than 100 milliseconds.", 9, "The operation lasted too long: It took 129 milliseconds, but should not have lasted longer than 100 milliseconds.", 9, "The operation lasted too long: It took 126 milliseconds, but should not have lasted longer than 100 milliseconds.", 9, "The operation lasted too long: It took 128 milliseconds, but should not have lasted longer than 100 milliseconds.", 9], "isController": false}, {"data": ["Moodle/moodle/course/view.php-310", 100, 2, "The operation lasted too long: It took 110 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, "The operation lasted too long: It took 104 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["Moodle/moodle/my/-307", 100, 12, "The operation lasted too long: It took 108 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, "The operation lasted too long: It took 102 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, "The operation lasted too long: It took 106 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, "The operation lasted too long: It took 114 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, "The operation lasted too long: It took 115 milliseconds, but should not have lasted longer than 100 milliseconds.", 1], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Moodle/moodle/user/profile.php-305", 100, 7, "The operation lasted too long: It took 118 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, "The operation lasted too long: It took 106 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, "The operation lasted too long: It took 2,381 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, "The operation lasted too long: It took 2,661 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, "The operation lasted too long: It took 2,309 milliseconds, but should not have lasted longer than 100 milliseconds.", 1], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});

/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 92.0, "KoPercent": 8.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.92, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.98, 500, 1500, "Notice/home/notice-417"], "isController": false}, {"data": [0.95, 500, 1500, "Notice/home/notice-428"], "isController": false}, {"data": [0.97, 500, 1500, "Notice/home/notice-415"], "isController": false}, {"data": [0.98, 500, 1500, "Notice/home/notice-426"], "isController": false}, {"data": [0.98, 500, 1500, "Notice/home/notice-413"], "isController": false}, {"data": [0.97, 500, 1500, "Notice/home/notice-423"], "isController": false}, {"data": [0.53, 500, 1500, "Notice/home/notice-411"], "isController": false}, {"data": [0.98, 500, 1500, "Notice/home/notice-421"], "isController": false}, {"data": [0.98, 500, 1500, "Notice/home/notice-420"], "isController": false}, {"data": [0.79, 500, 1500, "Notice/home/download/1300-418"], "isController": false}, {"data": [0.95, 500, 1500, "Notice/home/notice-419"], "isController": false}, {"data": [0.98, 500, 1500, "Notice/home/news_detail/184-424"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 1200, 96, 8.0, 25.279166666666622, 10, 398, 21.0, 38.0, 46.0, 87.95000000000005, 12.086174423640557, 137.96513673743792, 5.924074589321864], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Notice/home/notice-417", 100, 2, 2.0, 21.349999999999998, 13, 83, 20.0, 28.0, 31.0, 82.63999999999982, 1.0137669552523265, 3.5471943365909047, 0.5148035319640721], "isController": false}, {"data": ["Notice/home/notice-428", 100, 5, 5.0, 22.510000000000005, 14, 78, 19.5, 31.0, 42.59999999999991, 77.84999999999992, 1.0137464012002757, 3.547122417481043, 0.4544039044442642], "isController": false}, {"data": ["Notice/home/notice-415", 100, 3, 3.0, 22.100000000000005, 14, 49, 20.0, 31.0, 36.89999999999998, 48.969999999999985, 1.013787510137875, 3.547266258617194, 0.5148139699918897], "isController": false}, {"data": ["Notice/home/notice-426", 100, 2, 2.0, 20.81000000000001, 13, 48, 19.0, 29.0, 34.89999999999998, 47.95999999999998, 1.013725847981672, 3.5470505012874316, 0.45439469162459706], "isController": false}, {"data": ["Notice/home/notice-413", 100, 2, 2.0, 22.030000000000005, 13, 50, 20.0, 29.900000000000006, 35.89999999999998, 49.91999999999996, 1.0138491797960136, 3.547482042196403, 0.4990038931808504], "isController": false}, {"data": ["Notice/home/notice-423", 100, 3, 3.0, 20.73, 13, 45, 19.0, 27.900000000000006, 34.94999999999999, 44.97999999999999, 1.0135203616240651, 3.546331499706079, 0.454302583970162], "isController": false}, {"data": ["Notice/home/notice-411", 100, 47, 47.0, 51.71, 27, 398, 40.0, 68.9, 108.79999999999995, 396.6199999999993, 1.00999899000101, 3.534996465003535, 0.49710887789112207], "isController": false}, {"data": ["Notice/home/notice-421", 100, 2, 2.0, 21.509999999999994, 13, 63, 19.0, 29.900000000000006, 35.799999999999955, 62.91999999999996, 1.0134792743488394, 3.546187734367082, 0.5146574440052701], "isController": false}, {"data": ["Notice/home/notice-420", 100, 2, 2.0, 21.559999999999995, 12, 99, 19.0, 30.900000000000006, 36.0, 98.43999999999971, 1.0135922723725155, 3.546583117100315, 0.5147148258141679], "isController": false}, {"data": ["Notice/home/download/1300-418", 100, 21, 21.0, 37.28, 23, 114, 31.0, 54.900000000000006, 87.74999999999994, 113.87999999999994, 1.0135614522308487, 99.24587860574486, 0.5127195627495895], "isController": false}, {"data": ["Notice/home/notice-419", 100, 5, 5.0, 23.949999999999996, 15, 56, 22.0, 29.900000000000006, 41.59999999999991, 55.989999999999995, 1.0135819987837016, 3.5465471695722686, 0.5147096087573485], "isController": false}, {"data": ["Notice/home/news_detail/184-424", 100, 2, 2.0, 17.809999999999995, 10, 51, 16.0, 26.0, 31.899999999999977, 51.0, 1.0136333688105013, 4.1277843241599514, 0.5147356950990827], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["The operation lasted too long: It took 114 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 1.0416666666666667, 0.08333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 102 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, 2.0833333333333335, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 260 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 1.0416666666666667, 0.08333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 46 milliseconds, but should not have lasted longer than 40 milliseconds.", 4, 4.166666666666667, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 88 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 1.0416666666666667, 0.08333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 43 milliseconds, but should not have lasted longer than 40 milliseconds.", 8, 8.333333333333334, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 48 milliseconds, but should not have lasted longer than 40 milliseconds.", 4, 4.166666666666667, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 69 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 1.0416666666666667, 0.08333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 55 milliseconds, but should not have lasted longer than 40 milliseconds.", 3, 3.125, 0.25], "isController": false}, {"data": ["The operation lasted too long: It took 105 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 1.0416666666666667, 0.08333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 147 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 1.0416666666666667, 0.08333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 99 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, 2.0833333333333335, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 187 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 1.0416666666666667, 0.08333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 78 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 1.0416666666666667, 0.08333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 57 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, 2.0833333333333335, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 49 milliseconds, but should not have lasted longer than 40 milliseconds.", 4, 4.166666666666667, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 58 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 1.0416666666666667, 0.08333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 45 milliseconds, but should not have lasted longer than 40 milliseconds.", 4, 4.166666666666667, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 66 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 1.0416666666666667, 0.08333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 109 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 1.0416666666666667, 0.08333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 54 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, 2.0833333333333335, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 63 milliseconds, but should not have lasted longer than 40 milliseconds.", 3, 3.125, 0.25], "isController": false}, {"data": ["The operation lasted too long: It took 51 milliseconds, but should not have lasted longer than 40 milliseconds.", 3, 3.125, 0.25], "isController": false}, {"data": ["The operation lasted too long: It took 72 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 1.0416666666666667, 0.08333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 42 milliseconds, but should not have lasted longer than 40 milliseconds.", 10, 10.416666666666666, 0.8333333333333334], "isController": false}, {"data": ["The operation lasted too long: It took 47 milliseconds, but should not have lasted longer than 40 milliseconds.", 4, 4.166666666666667, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 41 milliseconds, but should not have lasted longer than 40 milliseconds.", 4, 4.166666666666667, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 44 milliseconds, but should not have lasted longer than 40 milliseconds.", 8, 8.333333333333334, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 56 milliseconds, but should not have lasted longer than 40 milliseconds.", 4, 4.166666666666667, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 50 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, 2.0833333333333335, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 65 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, 2.0833333333333335, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 59 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 1.0416666666666667, 0.08333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 398 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 1.0416666666666667, 0.08333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 83 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, 2.0833333333333335, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 74 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 1.0416666666666667, 0.08333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 53 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, 2.0833333333333335, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 71 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 1.0416666666666667, 0.08333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 68 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 1.0416666666666667, 0.08333333333333333], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 1200, 96, "The operation lasted too long: It took 42 milliseconds, but should not have lasted longer than 40 milliseconds.", 10, "The operation lasted too long: It took 43 milliseconds, but should not have lasted longer than 40 milliseconds.", 8, "The operation lasted too long: It took 44 milliseconds, but should not have lasted longer than 40 milliseconds.", 8, "The operation lasted too long: It took 46 milliseconds, but should not have lasted longer than 40 milliseconds.", 4, "The operation lasted too long: It took 48 milliseconds, but should not have lasted longer than 40 milliseconds.", 4], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["Notice/home/notice-417", 100, 2, "The operation lasted too long: It took 47 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "The operation lasted too long: It took 83 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "", "", "", "", "", ""], "isController": false}, {"data": ["Notice/home/notice-428", 100, 5, "The operation lasted too long: It took 44 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "The operation lasted too long: It took 50 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "The operation lasted too long: It took 78 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "The operation lasted too long: It took 63 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "The operation lasted too long: It took 43 milliseconds, but should not have lasted longer than 40 milliseconds.", 1], "isController": false}, {"data": ["Notice/home/notice-415", 100, 3, "The operation lasted too long: It took 49 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "The operation lasted too long: It took 45 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "The operation lasted too long: It took 46 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "", "", "", ""], "isController": false}, {"data": ["Notice/home/notice-426", 100, 2, "The operation lasted too long: It took 44 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "The operation lasted too long: It took 48 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "", "", "", "", "", ""], "isController": false}, {"data": ["Notice/home/notice-413", 100, 2, "The operation lasted too long: It took 50 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "The operation lasted too long: It took 42 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "", "", "", "", "", ""], "isController": false}, {"data": ["Notice/home/notice-423", 100, 3, "The operation lasted too long: It took 41 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "The operation lasted too long: It took 45 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "The operation lasted too long: It took 43 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "", "", "", ""], "isController": false}, {"data": ["Notice/home/notice-411", 100, 47, "The operation lasted too long: It took 42 milliseconds, but should not have lasted longer than 40 milliseconds.", 8, "The operation lasted too long: It took 44 milliseconds, but should not have lasted longer than 40 milliseconds.", 4, "The operation lasted too long: It took 43 milliseconds, but should not have lasted longer than 40 milliseconds.", 3, "The operation lasted too long: It took 46 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, "The operation lasted too long: It took 48 milliseconds, but should not have lasted longer than 40 milliseconds.", 2], "isController": false}, {"data": ["Notice/home/notice-421", 100, 2, "The operation lasted too long: It took 63 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "The operation lasted too long: It took 55 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "", "", "", "", "", ""], "isController": false}, {"data": ["Notice/home/notice-420", 100, 2, "The operation lasted too long: It took 99 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "The operation lasted too long: It took 43 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "", "", "", "", "", ""], "isController": false}, {"data": ["Notice/home/download/1300-418", 100, 21, "The operation lasted too long: It took 41 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, "The operation lasted too long: It took 44 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, "The operation lasted too long: It took 102 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, "The operation lasted too long: It took 43 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, "The operation lasted too long: It took 47 milliseconds, but should not have lasted longer than 40 milliseconds.", 1], "isController": false}, {"data": ["Notice/home/notice-419", 100, 5, "The operation lasted too long: It took 47 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "The operation lasted too long: It took 56 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "The operation lasted too long: It took 49 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "The operation lasted too long: It took 42 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "The operation lasted too long: It took 55 milliseconds, but should not have lasted longer than 40 milliseconds.", 1], "isController": false}, {"data": ["Notice/home/news_detail/184-424", 100, 2, "The operation lasted too long: It took 51 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, "", "", "", "", "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});

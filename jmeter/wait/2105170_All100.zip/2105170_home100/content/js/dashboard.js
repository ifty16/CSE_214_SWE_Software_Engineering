/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 98.27272727272727, "KoPercent": 1.7272727272727273};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9827272727272728, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "Home/home/news_detail/166-342"], "isController": false}, {"data": [0.99, 500, 1500, "Home/home/ra-358"], "isController": false}, {"data": [1.0, 500, 1500, "Home/home/all_news-341"], "isController": false}, {"data": [1.0, 500, 1500, "Home/home/news_detail/184-360"], "isController": false}, {"data": [1.0, 500, 1500, "Home/home-404"], "isController": false}, {"data": [0.84, 500, 1500, "Home/home-321"], "isController": false}, {"data": [1.0, 500, 1500, "Home/home/aboutus-322"], "isController": false}, {"data": [1.0, 500, 1500, "Home/home/pg_cc-324"], "isController": false}, {"data": [1.0, 500, 1500, "Home/home/mission_vision-347"], "isController": false}, {"data": [1.0, 500, 1500, "Home/home/award-348"], "isController": false}, {"data": [0.98, 500, 1500, "Home/home-323"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 1100, 19, 1.7272727272727273, 26.967272727272746, 9, 2629, 16.0, 32.0, 39.0, 59.99000000000001, 11.085245538188671, 55.412449864457685, 5.529829073071923], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Home/home/news_detail/166-342", 100, 0, 0.0, 14.920000000000003, 11, 29, 14.0, 19.0, 20.0, 28.95999999999998, 1.010090807163564, 3.722737017807901, 0.5149095716204887], "isController": false}, {"data": ["Home/home/ra-358", 100, 1, 1.0, 24.52, 17, 55, 24.0, 30.0, 32.0, 54.81999999999991, 1.0100193923723337, 4.937653396695217, 0.5089550844376213], "isController": false}, {"data": ["Home/home/all_news-341", 100, 0, 0.0, 14.700000000000003, 11, 21, 14.0, 18.0, 19.94999999999999, 21.0, 1.0101418239120772, 2.9071171436219645, 0.4991521122065538], "isController": false}, {"data": ["Home/home/news_detail/184-360", 100, 0, 0.0, 15.430000000000001, 11, 39, 14.0, 19.900000000000006, 21.94999999999999, 38.909999999999954, 1.0101112132445782, 4.113441171122941, 0.5139335372074466], "isController": false}, {"data": ["Home/home-404", 100, 0, 0.0, 20.229999999999993, 13, 46, 19.0, 26.0, 28.0, 45.85999999999993, 1.0100806044322337, 7.394105674632836, 0.5139179637785095], "isController": false}, {"data": ["Home/home-321", 100, 16, 16.0, 129.09999999999997, 31, 2629, 39.0, 59.900000000000006, 347.94999999999703, 2626.1899999999987, 1.0096624698363337, 7.392030797229486, 0.48609726330987546], "isController": false}, {"data": ["Home/home/aboutus-322", 100, 0, 0.0, 14.190000000000003, 10, 46, 13.0, 18.0, 19.0, 45.78999999999989, 1.0104888745174916, 6.598768656150845, 0.49833679846809886], "isController": false}, {"data": ["Home/home/pg_cc-324", 100, 0, 0.0, 12.99, 9, 27, 12.0, 18.0, 19.94999999999999, 26.989999999999995, 1.0102030508132136, 4.560711624911607, 0.49622278765531874], "isController": false}, {"data": ["Home/home/mission_vision-347", 100, 0, 0.0, 13.540000000000004, 9, 39, 13.0, 17.900000000000006, 20.0, 38.85999999999993, 1.0101214165942747, 2.985974148467646, 0.5139387285601729], "isController": false}, {"data": ["Home/home/award-348", 100, 0, 0.0, 15.860000000000003, 11, 49, 15.0, 19.0, 24.94999999999999, 48.81999999999991, 1.0101010101010102, 3.5343671085858586, 0.5109690656565656], "isController": false}, {"data": ["Home/home-323", 100, 2, 2.0, 21.16, 15, 64, 19.0, 26.0, 34.69999999999993, 63.89999999999995, 1.0102234614296683, 7.395151432496868, 0.4863673500828383], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["The operation lasted too long: It took 2,283 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, 5.2631578947368425, 0.09090909090909091], "isController": false}, {"data": ["The operation lasted too long: It took 361 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, 5.2631578947368425, 0.09090909090909091], "isController": false}, {"data": ["The operation lasted too long: It took 54 milliseconds, but should not have lasted longer than 50 milliseconds.", 3, 15.789473684210526, 0.2727272727272727], "isController": false}, {"data": ["The operation lasted too long: It took 60 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, 5.2631578947368425, 0.09090909090909091], "isController": false}, {"data": ["The operation lasted too long: It took 2,629 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, 5.2631578947368425, 0.09090909090909091], "isController": false}, {"data": ["The operation lasted too long: It took 56 milliseconds, but should not have lasted longer than 50 milliseconds.", 2, 10.526315789473685, 0.18181818181818182], "isController": false}, {"data": ["The operation lasted too long: It took 1,360 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, 5.2631578947368425, 0.09090909090909091], "isController": false}, {"data": ["The operation lasted too long: It took 2,348 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, 5.2631578947368425, 0.09090909090909091], "isController": false}, {"data": ["The operation lasted too long: It took 59 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, 5.2631578947368425, 0.09090909090909091], "isController": false}, {"data": ["The operation lasted too long: It took 70 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, 5.2631578947368425, 0.09090909090909091], "isController": false}, {"data": ["The operation lasted too long: It took 62 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, 5.2631578947368425, 0.09090909090909091], "isController": false}, {"data": ["The operation lasted too long: It took 79 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, 5.2631578947368425, 0.09090909090909091], "isController": false}, {"data": ["The operation lasted too long: It took 55 milliseconds, but should not have lasted longer than 50 milliseconds.", 2, 10.526315789473685, 0.18181818181818182], "isController": false}, {"data": ["The operation lasted too long: It took 100 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, 5.2631578947368425, 0.09090909090909091], "isController": false}, {"data": ["The operation lasted too long: It took 64 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, 5.2631578947368425, 0.09090909090909091], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 1100, 19, "The operation lasted too long: It took 54 milliseconds, but should not have lasted longer than 50 milliseconds.", 3, "The operation lasted too long: It took 56 milliseconds, but should not have lasted longer than 50 milliseconds.", 2, "The operation lasted too long: It took 55 milliseconds, but should not have lasted longer than 50 milliseconds.", 2, "The operation lasted too long: It took 2,283 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, "The operation lasted too long: It took 361 milliseconds, but should not have lasted longer than 50 milliseconds.", 1], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": ["Home/home/ra-358", 100, 1, "The operation lasted too long: It took 55 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Home/home-321", 100, 16, "The operation lasted too long: It took 54 milliseconds, but should not have lasted longer than 50 milliseconds.", 2, "The operation lasted too long: It took 56 milliseconds, but should not have lasted longer than 50 milliseconds.", 2, "The operation lasted too long: It took 2,283 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, "The operation lasted too long: It took 361 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, "The operation lasted too long: It took 60 milliseconds, but should not have lasted longer than 50 milliseconds.", 1], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Home/home-323", 100, 2, "The operation lasted too long: It took 54 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, "The operation lasted too long: It took 64 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, "", "", "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});

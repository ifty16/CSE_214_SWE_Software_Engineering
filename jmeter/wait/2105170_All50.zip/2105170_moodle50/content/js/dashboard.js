/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 88.08695652173913, "KoPercent": 11.91304347826087};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.8808695652173913, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "Moodle/moodle/course/view.php-314-2"], "isController": false}, {"data": [1.0, 500, 1500, "Moodle/moodle/course/view.php-314-1"], "isController": false}, {"data": [1.0, 500, 1500, "Moodle/moodle/h5p/h5plib/v124/joubel/core/js/h5p-resizer.js-318"], "isController": false}, {"data": [0.68, 500, 1500, "Moodle/moodle/mod/forum/view.php-312"], "isController": false}, {"data": [0.76, 500, 1500, "Moodle/moodle/course/view.php-311"], "isController": false}, {"data": [1.0, 500, 1500, "Moodle/moodle/theme/image.php/classic/folder/1731384351/monologo-313"], "isController": false}, {"data": [0.0, 500, 1500, "Moodle/moodle/-319"], "isController": false}, {"data": [0.68, 500, 1500, "Moodle/moodle/course/view.php-310"], "isController": false}, {"data": [1.0, 500, 1500, "Moodle/moodle/calendar/view.php-320"], "isController": false}, {"data": [0.62, 500, 1500, "Moodle/moodle/my/-307"], "isController": false}, {"data": [1.0, 500, 1500, "Moodle/moodle/mod/forum/view.php-312-2"], "isController": false}, {"data": [1.0, 500, 1500, "Moodle/moodle/mod/forum/view.php-312-0"], "isController": false}, {"data": [1.0, 500, 1500, "Moodle/moodle/mod/forum/post.php-317"], "isController": false}, {"data": [1.0, 500, 1500, "Moodle/moodle/mod/forum/view.php-312-1"], "isController": false}, {"data": [0.7, 500, 1500, "Moodle/moodle/course/view.php-314"], "isController": false}, {"data": [1.0, 500, 1500, "Moodle/moodle/course/view.php-310-0"], "isController": false}, {"data": [1.0, 500, 1500, "Moodle/moodle/course/view.php-310-2"], "isController": false}, {"data": [1.0, 500, 1500, "Moodle/moodle/course/view.php-311-1"], "isController": false}, {"data": [0.82, 500, 1500, "Moodle/moodle/user/profile.php-305"], "isController": false}, {"data": [1.0, 500, 1500, "Moodle/moodle/course/view.php-310-1"], "isController": false}, {"data": [1.0, 500, 1500, "Moodle/moodle/course/view.php-311-0"], "isController": false}, {"data": [1.0, 500, 1500, "Moodle/moodle/course/view.php-314-0"], "isController": false}, {"data": [1.0, 500, 1500, "Moodle/moodle/course/view.php-311-2"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 1150, 137, 11.91304347826087, 50.15652173913046, 3, 209, 38.0, 104.0, 125.0, 143.0, 11.631199935269844, 68.07489655185492, 8.259179165992395], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Moodle/moodle/course/view.php-314-2", 50, 0, 0.0, 33.24, 22, 49, 32.5, 43.9, 45.89999999999999, 49.0, 0.5097983237831114, 3.33108398098962, 0.269834659658639], "isController": false}, {"data": ["Moodle/moodle/course/view.php-314-1", 50, 0, 0.0, 21.580000000000002, 11, 54, 20.5, 31.9, 37.34999999999999, 54.0, 0.5098867031745545, 1.000851829473491, 0.2728690559957577], "isController": false}, {"data": ["Moodle/moodle/h5p/h5plib/v124/joubel/core/js/h5p-resizer.js-318", 50, 0, 0.0, 12.379999999999999, 3, 28, 12.0, 24.799999999999997, 25.89999999999999, 28.0, 0.5097567440817242, 0.7974905312684787, 0.2210273382541851], "isController": false}, {"data": ["Moodle/moodle/mod/forum/view.php-312", 50, 16, 32.0, 86.96000000000001, 57, 131, 86.5, 114.8, 123.44999999999999, 131.0, 0.509626851219537, 5.375100093898747, 0.8122177941311371], "isController": false}, {"data": ["Moodle/moodle/course/view.php-311", 50, 12, 24.0, 84.78, 55, 132, 81.0, 117.8, 127.89999999999999, 132.0, 0.5097203674064409, 5.376016732845361, 0.810873514165129], "isController": false}, {"data": ["Moodle/moodle/theme/image.php/classic/folder/1731384351/monologo-313", 50, 0, 0.0, 12.6, 4, 25, 12.0, 19.9, 22.449999999999996, 25.0, 0.509933504670991, 0.5004718478460408, 0.26343244528413495], "isController": false}, {"data": ["Moodle/moodle/-319", 50, 50, 100.0, 136.17999999999998, 120, 183, 136.0, 145.9, 156.84999999999994, 183.0, 0.509056108164242, 6.005649091080318, 0.26894468214536604], "isController": false}, {"data": ["Moodle/moodle/course/view.php-310", 50, 16, 32.0, 92.22, 61, 145, 85.5, 128.9, 134.7, 145.0, 0.5097359567743908, 5.376181153787338, 0.8108983140483229], "isController": false}, {"data": ["Moodle/moodle/calendar/view.php-320", 50, 0, 0.0, 52.699999999999996, 40, 73, 51.0, 63.9, 68.44999999999999, 73.0, 0.5094451123835918, 4.152107017224339, 0.2711402209463452], "isController": false}, {"data": ["Moodle/moodle/my/-307", 50, 19, 38.0, 100.66, 90, 121, 99.0, 113.6, 118.89999999999999, 121.0, 0.5097619411734721, 7.014155053652445, 0.2643394441046032], "isController": false}, {"data": ["Moodle/moodle/mod/forum/view.php-312-2", 50, 0, 0.0, 32.900000000000006, 23, 55, 33.0, 43.0, 48.0, 55.0, 0.5098451090558688, 3.3315490082238015, 0.2683657361143684], "isController": false}, {"data": ["Moodle/moodle/mod/forum/view.php-312-0", 50, 0, 0.0, 33.5, 21, 51, 32.5, 43.0, 48.449999999999996, 51.0, 0.5098711045847609, 1.0451361801986458, 0.2728607083129385], "isController": false}, {"data": ["Moodle/moodle/mod/forum/post.php-317", 50, 0, 0.0, 53.359999999999985, 41, 75, 51.0, 63.9, 66.79999999999998, 75.0, 0.5096424348676968, 3.7295971818047455, 0.2767199158070697], "isController": false}, {"data": ["Moodle/moodle/mod/forum/view.php-312-1", 50, 0, 0.0, 20.480000000000004, 10, 44, 20.0, 31.699999999999996, 33.449999999999996, 44.0, 0.5099231035959777, 1.0009232795194485, 0.2713946205662186], "isController": false}, {"data": ["Moodle/moodle/course/view.php-314", 50, 15, 30.0, 87.90000000000002, 59, 128, 86.5, 114.0, 119.44999999999999, 128.0, 0.5096112685243696, 5.374776487682696, 0.815178962737224], "isController": false}, {"data": ["Moodle/moodle/course/view.php-310-0", 50, 0, 0.0, 33.260000000000005, 22, 52, 30.5, 46.9, 50.449999999999996, 52.0, 0.5101207966046359, 1.0456480000714168, 0.27149983803664707], "isController": false}, {"data": ["Moodle/moodle/course/view.php-310-2", 50, 0, 0.0, 35.599999999999994, 24, 52, 34.5, 46.0, 48.79999999999998, 52.0, 0.5101832578262112, 3.333688867291131, 0.2685437265315701], "isController": false}, {"data": ["Moodle/moodle/course/view.php-311-1", 50, 0, 0.0, 19.900000000000006, 11, 39, 18.5, 29.799999999999997, 37.449999999999996, 39.0, 0.5101312057461179, 1.001331761279001, 0.2715053780582366], "isController": false}, {"data": ["Moodle/moodle/user/profile.php-305", 50, 9, 18.0, 82.36, 50, 209, 77.0, 104.9, 124.49999999999996, 209.0, 0.509777533084562, 3.398513568366265, 0.2598670627638099], "isController": false}, {"data": ["Moodle/moodle/course/view.php-310-1", 50, 0, 0.0, 23.3, 11, 61, 19.5, 38.8, 51.0, 61.0, 0.5102301137813154, 1.0015259069340272, 0.27155801954181336], "isController": false}, {"data": ["Moodle/moodle/course/view.php-311-0", 50, 0, 0.0, 31.639999999999993, 19, 58, 31.0, 40.9, 49.79999999999998, 58.0, 0.5101936695169487, 1.0457973753086671, 0.2715386229362666], "isController": false}, {"data": ["Moodle/moodle/course/view.php-314-0", 50, 0, 0.0, 32.97999999999999, 21, 48, 32.0, 42.9, 45.34999999999999, 48.0, 0.5098347115865036, 1.0450615816602258, 0.2728412323724648], "isController": false}, {"data": ["Moodle/moodle/course/view.php-311-2", 50, 0, 0.0, 33.12, 22, 52, 33.0, 42.9, 48.79999999999998, 52.0, 0.5099283040804462, 3.33202292382691, 0.2684095272454693], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["The operation lasted too long: It took 140 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 1.4598540145985401, 0.17391304347826086], "isController": false}, {"data": ["The operation lasted too long: It took 136 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, 2.18978102189781, 0.2608695652173913], "isController": false}, {"data": ["The operation lasted too long: It took 115 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, 2.18978102189781, 0.2608695652173913], "isController": false}, {"data": ["The operation lasted too long: It took 147 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.7299270072992701, 0.08695652173913043], "isController": false}, {"data": ["The operation lasted too long: It took 126 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 1.4598540145985401, 0.17391304347826086], "isController": false}, {"data": ["The operation lasted too long: It took 114 milliseconds, but should not have lasted longer than 100 milliseconds.", 4, 2.9197080291970803, 0.34782608695652173], "isController": false}, {"data": ["The operation lasted too long: It took 183 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.7299270072992701, 0.08695652173913043], "isController": false}, {"data": ["The operation lasted too long: It took 141 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 1.4598540145985401, 0.17391304347826086], "isController": false}, {"data": ["The operation lasted too long: It took 146 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.7299270072992701, 0.08695652173913043], "isController": false}, {"data": ["The operation lasted too long: It took 151 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.7299270072992701, 0.08695652173913043], "isController": false}, {"data": ["The operation lasted too long: It took 125 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, 2.18978102189781, 0.2608695652173913], "isController": false}, {"data": ["The operation lasted too long: It took 104 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, 2.18978102189781, 0.2608695652173913], "isController": false}, {"data": ["The operation lasted too long: It took 130 milliseconds, but should not have lasted longer than 100 milliseconds.", 4, 2.9197080291970803, 0.34782608695652173], "isController": false}, {"data": ["The operation lasted too long: It took 109 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, 2.18978102189781, 0.2608695652173913], "isController": false}, {"data": ["The operation lasted too long: It took 106 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, 2.18978102189781, 0.2608695652173913], "isController": false}, {"data": ["The operation lasted too long: It took 110 milliseconds, but should not have lasted longer than 100 milliseconds.", 5, 3.6496350364963503, 0.43478260869565216], "isController": false}, {"data": ["The operation lasted too long: It took 103 milliseconds, but should not have lasted longer than 100 milliseconds.", 8, 5.839416058394161, 0.6956521739130435], "isController": false}, {"data": ["The operation lasted too long: It took 120 milliseconds, but should not have lasted longer than 100 milliseconds.", 4, 2.9197080291970803, 0.34782608695652173], "isController": false}, {"data": ["The operation lasted too long: It took 138 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, 2.18978102189781, 0.2608695652173913], "isController": false}, {"data": ["The operation lasted too long: It took 132 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, 2.18978102189781, 0.2608695652173913], "isController": false}, {"data": ["The operation lasted too long: It took 116 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 1.4598540145985401, 0.17391304347826086], "isController": false}, {"data": ["The operation lasted too long: It took 113 milliseconds, but should not have lasted longer than 100 milliseconds.", 4, 2.9197080291970803, 0.34782608695652173], "isController": false}, {"data": ["The operation lasted too long: It took 145 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 1.4598540145985401, 0.17391304347826086], "isController": false}, {"data": ["The operation lasted too long: It took 119 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.7299270072992701, 0.08695652173913043], "isController": false}, {"data": ["The operation lasted too long: It took 209 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.7299270072992701, 0.08695652173913043], "isController": false}, {"data": ["The operation lasted too long: It took 142 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, 2.18978102189781, 0.2608695652173913], "isController": false}, {"data": ["The operation lasted too long: It took 101 milliseconds, but should not have lasted longer than 100 milliseconds.", 7, 5.109489051094891, 0.6086956521739131], "isController": false}, {"data": ["The operation lasted too long: It took 118 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 1.4598540145985401, 0.17391304347826086], "isController": false}, {"data": ["The operation lasted too long: It took 122 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, 2.18978102189781, 0.2608695652173913], "isController": false}, {"data": ["The operation lasted too long: It took 143 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, 2.18978102189781, 0.2608695652173913], "isController": false}, {"data": ["The operation lasted too long: It took 139 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.7299270072992701, 0.08695652173913043], "isController": false}, {"data": ["The operation lasted too long: It took 164 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.7299270072992701, 0.08695652173913043], "isController": false}, {"data": ["The operation lasted too long: It took 129 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, 2.18978102189781, 0.2608695652173913], "isController": false}, {"data": ["The operation lasted too long: It took 111 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 1.4598540145985401, 0.17391304347826086], "isController": false}, {"data": ["The operation lasted too long: It took 123 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, 0.7299270072992701, 0.08695652173913043], "isController": false}, {"data": ["The operation lasted too long: It took 144 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 1.4598540145985401, 0.17391304347826086], "isController": false}, {"data": ["The operation lasted too long: It took 107 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 1.4598540145985401, 0.17391304347826086], "isController": false}, {"data": ["The operation lasted too long: It took 133 milliseconds, but should not have lasted longer than 100 milliseconds.", 4, 2.9197080291970803, 0.34782608695652173], "isController": false}, {"data": ["The operation lasted too long: It took 128 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, 2.18978102189781, 0.2608695652173913], "isController": false}, {"data": ["The operation lasted too long: It took 131 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, 2.18978102189781, 0.2608695652173913], "isController": false}, {"data": ["The operation lasted too long: It took 124 milliseconds, but should not have lasted longer than 100 milliseconds.", 5, 3.6496350364963503, 0.43478260869565216], "isController": false}, {"data": ["The operation lasted too long: It took 127 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 1.4598540145985401, 0.17391304347826086], "isController": false}, {"data": ["The operation lasted too long: It took 134 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 1.4598540145985401, 0.17391304347826086], "isController": false}, {"data": ["The operation lasted too long: It took 105 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, 2.18978102189781, 0.2608695652173913], "isController": false}, {"data": ["The operation lasted too long: It took 102 milliseconds, but should not have lasted longer than 100 milliseconds.", 5, 3.6496350364963503, 0.43478260869565216], "isController": false}, {"data": ["The operation lasted too long: It took 108 milliseconds, but should not have lasted longer than 100 milliseconds.", 6, 4.37956204379562, 0.5217391304347826], "isController": false}, {"data": ["The operation lasted too long: It took 121 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, 2.18978102189781, 0.2608695652173913], "isController": false}, {"data": ["The operation lasted too long: It took 137 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, 1.4598540145985401, 0.17391304347826086], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 1150, 137, "The operation lasted too long: It took 103 milliseconds, but should not have lasted longer than 100 milliseconds.", 8, "The operation lasted too long: It took 101 milliseconds, but should not have lasted longer than 100 milliseconds.", 7, "The operation lasted too long: It took 108 milliseconds, but should not have lasted longer than 100 milliseconds.", 6, "The operation lasted too long: It took 124 milliseconds, but should not have lasted longer than 100 milliseconds.", 5, "The operation lasted too long: It took 110 milliseconds, but should not have lasted longer than 100 milliseconds.", 5], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Moodle/moodle/mod/forum/view.php-312", 50, 16, "The operation lasted too long: It took 103 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, "The operation lasted too long: It took 101 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, "The operation lasted too long: It took 110 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, "The operation lasted too long: It took 123 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, "The operation lasted too long: It took 109 milliseconds, but should not have lasted longer than 100 milliseconds.", 1], "isController": false}, {"data": ["Moodle/moodle/course/view.php-311", 50, 12, "The operation lasted too long: It took 103 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, "The operation lasted too long: It took 102 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, "The operation lasted too long: It took 118 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, "The operation lasted too long: It took 106 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, "The operation lasted too long: It took 132 milliseconds, but should not have lasted longer than 100 milliseconds.", 1], "isController": false}, {"data": [], "isController": false}, {"data": ["Moodle/moodle/-319", 50, 50, "The operation lasted too long: It took 133 milliseconds, but should not have lasted longer than 100 milliseconds.", 4, "The operation lasted too long: It took 136 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, "The operation lasted too long: It took 122 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, "The operation lasted too long: It took 143 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, "The operation lasted too long: It took 125 milliseconds, but should not have lasted longer than 100 milliseconds.", 3], "isController": false}, {"data": ["Moodle/moodle/course/view.php-310", 50, 16, "The operation lasted too long: It took 129 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, "The operation lasted too long: It took 111 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, "The operation lasted too long: It took 101 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, "The operation lasted too long: It took 115 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, "The operation lasted too long: It took 124 milliseconds, but should not have lasted longer than 100 milliseconds.", 1], "isController": false}, {"data": [], "isController": false}, {"data": ["Moodle/moodle/my/-307", 50, 19, "The operation lasted too long: It took 101 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, "The operation lasted too long: It took 109 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, "The operation lasted too long: It took 106 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, "The operation lasted too long: It took 108 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, "The operation lasted too long: It took 118 milliseconds, but should not have lasted longer than 100 milliseconds.", 1], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Moodle/moodle/course/view.php-314", 50, 15, "The operation lasted too long: It took 114 milliseconds, but should not have lasted longer than 100 milliseconds.", 3, "The operation lasted too long: It took 102 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, "The operation lasted too long: It took 108 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, "The operation lasted too long: It took 105 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, "The operation lasted too long: It took 101 milliseconds, but should not have lasted longer than 100 milliseconds.", 1], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Moodle/moodle/user/profile.php-305", 50, 9, "The operation lasted too long: It took 103 milliseconds, but should not have lasted longer than 100 milliseconds.", 2, "The operation lasted too long: It took 105 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, "The operation lasted too long: It took 102 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, "The operation lasted too long: It took 113 milliseconds, but should not have lasted longer than 100 milliseconds.", 1, "The operation lasted too long: It took 120 milliseconds, but should not have lasted longer than 100 milliseconds.", 1], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});

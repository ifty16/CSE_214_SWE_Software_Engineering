/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 82.83333333333333, "KoPercent": 17.166666666666668};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.8283333333333334, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "Notice/home/notice-417"], "isController": false}, {"data": [0.92, 500, 1500, "Notice/home/notice-428"], "isController": false}, {"data": [0.94, 500, 1500, "Notice/home/notice-415"], "isController": false}, {"data": [0.92, 500, 1500, "Notice/home/notice-426"], "isController": false}, {"data": [0.96, 500, 1500, "Notice/home/notice-413"], "isController": false}, {"data": [0.86, 500, 1500, "Notice/home/notice-423"], "isController": false}, {"data": [0.2, 500, 1500, "Notice/home/notice-411"], "isController": false}, {"data": [0.98, 500, 1500, "Notice/home/notice-421"], "isController": false}, {"data": [1.0, 500, 1500, "Notice/home/notice-420"], "isController": false}, {"data": [0.34, 500, 1500, "Notice/home/download/1300-418"], "isController": false}, {"data": [0.88, 500, 1500, "Notice/home/notice-419"], "isController": false}, {"data": [0.94, 500, 1500, "Notice/home/news_detail/184-424"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 600, 103, 17.166666666666668, 32.056666666666686, 11, 139, 27.0, 51.0, 66.0, 105.98000000000002, 6.105254589116366, 69.6922164681611, 2.9925088208209534], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Notice/home/notice-417", 50, 0, 0.0, 25.02, 14, 40, 23.5, 34.9, 37.449999999999996, 40.0, 0.5103863624763947, 1.7858538444852754, 0.25918057469504413], "isController": false}, {"data": ["Notice/home/notice-428", 50, 4, 8.0, 27.76, 16, 65, 25.0, 39.9, 46.94999999999995, 65.0, 0.510662635836261, 1.786820531446605, 0.22890053696176157], "isController": false}, {"data": ["Notice/home/notice-415", 50, 3, 6.0, 26.44000000000001, 13, 53, 25.0, 36.0, 43.0, 53.0, 0.5103446868014657, 1.7857080203219255, 0.2591594112663693], "isController": false}, {"data": ["Notice/home/notice-426", 50, 4, 8.0, 28.459999999999997, 17, 53, 27.0, 38.9, 50.89999999999999, 53.0, 0.510667851416082, 1.7868387808826383, 0.22890287480466953], "isController": false}, {"data": ["Notice/home/notice-413", 50, 2, 4.0, 26.72, 16, 42, 24.5, 38.9, 40.449999999999996, 42.0, 0.510282186048885, 1.7854893287237843, 0.2511545134459356], "isController": false}, {"data": ["Notice/home/notice-423", 50, 7, 14.0, 28.880000000000003, 14, 52, 26.5, 42.8, 47.14999999999997, 52.0, 0.5106157004115564, 1.7866563032955136, 0.2288794985243206], "isController": false}, {"data": ["Notice/home/notice-411", 50, 40, 80.0, 61.94, 32, 139, 54.5, 103.29999999999998, 109.24999999999997, 139.0, 0.510037538762853, 1.7851313856699853, 0.2510341011098417], "isController": false}, {"data": ["Notice/home/notice-421", 50, 1, 2.0, 26.54, 14, 46, 24.5, 36.9, 39.449999999999996, 46.0, 0.5105374938735501, 1.7863826567860643, 0.25925732110766214], "isController": false}, {"data": ["Notice/home/notice-420", 50, 0, 0.0, 26.040000000000006, 13, 40, 25.0, 34.9, 37.89999999999999, 40.0, 0.5105166428425567, 1.7863096985399225, 0.2592467326934858], "isController": false}, {"data": ["Notice/home/download/1300-418", 50, 33, 66.0, 53.48000000000001, 27, 117, 47.0, 87.6, 104.79999999999998, 117.0, 0.5103342689461597, 49.97089499872417, 0.25815737433018626], "isController": false}, {"data": ["Notice/home/notice-419", 50, 6, 12.0, 28.720000000000002, 15, 51, 27.0, 42.0, 46.0, 51.0, 0.5104019926093792, 1.7859085346869195, 0.25918851187195036], "isController": false}, {"data": ["Notice/home/news_detail/184-424", 50, 3, 6.0, 24.67999999999999, 11, 65, 22.0, 36.0, 47.14999999999997, 65.0, 0.510673067102441, 2.079596376774589, 0.25932616688795834], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["The operation lasted too long: It took 117 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 0.970873786407767, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 79 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 0.970873786407767, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 76 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 0.970873786407767, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 73 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 0.970873786407767, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 52 milliseconds, but should not have lasted longer than 40 milliseconds.", 5, 4.854368932038835, 0.8333333333333334], "isController": false}, {"data": ["The operation lasted too long: It took 94 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 0.970873786407767, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 46 milliseconds, but should not have lasted longer than 40 milliseconds.", 4, 3.883495145631068, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 88 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 0.970873786407767, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 43 milliseconds, but should not have lasted longer than 40 milliseconds.", 8, 7.766990291262136, 1.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 48 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, 1.941747572815534, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 69 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 0.970873786407767, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 55 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, 1.941747572815534, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 97 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, 1.941747572815534, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 84 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 0.970873786407767, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 78 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 0.970873786407767, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 60 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 0.970873786407767, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 57 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 0.970873786407767, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 45 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, 1.941747572815534, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 58 milliseconds, but should not have lasted longer than 40 milliseconds.", 3, 2.912621359223301, 0.5], "isController": false}, {"data": ["The operation lasted too long: It took 66 milliseconds, but should not have lasted longer than 40 milliseconds.", 3, 2.912621359223301, 0.5], "isController": false}, {"data": ["The operation lasted too long: It took 106 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 0.970873786407767, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 54 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, 1.941747572815534, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 63 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 0.970873786407767, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 51 milliseconds, but should not have lasted longer than 40 milliseconds.", 4, 3.883495145631068, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 72 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 0.970873786407767, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 42 milliseconds, but should not have lasted longer than 40 milliseconds.", 8, 7.766990291262136, 1.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 139 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 0.970873786407767, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 47 milliseconds, but should not have lasted longer than 40 milliseconds.", 3, 2.912621359223301, 0.5], "isController": false}, {"data": ["The operation lasted too long: It took 44 milliseconds, but should not have lasted longer than 40 milliseconds.", 6, 5.825242718446602, 1.0], "isController": false}, {"data": ["The operation lasted too long: It took 41 milliseconds, but should not have lasted longer than 40 milliseconds.", 7, 6.796116504854369, 1.1666666666666667], "isController": false}, {"data": ["The operation lasted too long: It took 56 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 0.970873786407767, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 50 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, 1.941747572815534, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 62 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 0.970873786407767, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 65 milliseconds, but should not have lasted longer than 40 milliseconds.", 4, 3.883495145631068, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 59 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, 1.941747572815534, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 83 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 0.970873786407767, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 53 milliseconds, but should not have lasted longer than 40 milliseconds.", 3, 2.912621359223301, 0.5], "isController": false}, {"data": ["The operation lasted too long: It took 74 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, 1.941747572815534, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 103 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 0.970873786407767, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 112 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 0.970873786407767, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 80 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, 1.941747572815534, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 92 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 0.970873786407767, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 104 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 0.970873786407767, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 107 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, 1.941747572815534, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 91 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 0.970873786407767, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 89 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 0.970873786407767, 0.16666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 68 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, 0.970873786407767, 0.16666666666666666], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 600, 103, "The operation lasted too long: It took 43 milliseconds, but should not have lasted longer than 40 milliseconds.", 8, "The operation lasted too long: It took 42 milliseconds, but should not have lasted longer than 40 milliseconds.", 8, "The operation lasted too long: It took 41 milliseconds, but should not have lasted longer than 40 milliseconds.", 7, "The operation lasted too long: It took 44 milliseconds, but should not have lasted longer than 40 milliseconds.", 6, "The operation lasted too long: It took 52 milliseconds, but should not have lasted longer than 40 milliseconds.", 5], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": ["Notice/home/notice-428", 50, 4, "The operation lasted too long: It took 41 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "The operation lasted too long: It took 65 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "The operation lasted too long: It took 53 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "The operation lasted too long: It took 42 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "", ""], "isController": false}, {"data": ["Notice/home/notice-415", 50, 3, "The operation lasted too long: It took 43 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, "The operation lasted too long: It took 53 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "", "", "", "", "", ""], "isController": false}, {"data": ["Notice/home/notice-426", 50, 4, "The operation lasted too long: It took 50 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "The operation lasted too long: It took 45 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "The operation lasted too long: It took 53 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "The operation lasted too long: It took 52 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "", ""], "isController": false}, {"data": ["Notice/home/notice-413", 50, 2, "The operation lasted too long: It took 41 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "The operation lasted too long: It took 42 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "", "", "", "", "", ""], "isController": false}, {"data": ["Notice/home/notice-423", 50, 7, "The operation lasted too long: It took 41 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, "The operation lasted too long: It took 43 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, "The operation lasted too long: It took 44 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "The operation lasted too long: It took 52 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "The operation lasted too long: It took 51 milliseconds, but should not have lasted longer than 40 milliseconds.", 1], "isController": false}, {"data": ["Notice/home/notice-411", 50, 40, "The operation lasted too long: It took 44 milliseconds, but should not have lasted longer than 40 milliseconds.", 3, "The operation lasted too long: It took 52 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, "The operation lasted too long: It took 43 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, "The operation lasted too long: It took 97 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, "The operation lasted too long: It took 66 milliseconds, but should not have lasted longer than 40 milliseconds.", 2], "isController": false}, {"data": ["Notice/home/notice-421", 50, 1, "The operation lasted too long: It took 46 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["Notice/home/download/1300-418", 50, 33, "The operation lasted too long: It took 47 milliseconds, but should not have lasted longer than 40 milliseconds.", 3, "The operation lasted too long: It took 43 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, "The operation lasted too long: It took 58 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, "The operation lasted too long: It took 42 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, "The operation lasted too long: It took 65 milliseconds, but should not have lasted longer than 40 milliseconds.", 2], "isController": false}, {"data": ["Notice/home/notice-419", 50, 6, "The operation lasted too long: It took 46 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, "The operation lasted too long: It took 42 milliseconds, but should not have lasted longer than 40 milliseconds.", 2, "The operation lasted too long: It took 44 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "The operation lasted too long: It took 51 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "", ""], "isController": false}, {"data": ["Notice/home/news_detail/184-424", 50, 3, "The operation lasted too long: It took 44 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "The operation lasted too long: It took 65 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "The operation lasted too long: It took 51 milliseconds, but should not have lasted longer than 40 milliseconds.", 1, "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});

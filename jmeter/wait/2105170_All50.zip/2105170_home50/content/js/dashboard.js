/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 93.27272727272727, "KoPercent": 6.7272727272727275};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9327272727272727, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "Home/home/news_detail/166-342"], "isController": false}, {"data": [1.0, 500, 1500, "Home/home/ra-358"], "isController": false}, {"data": [1.0, 500, 1500, "Home/home/all_news-341"], "isController": false}, {"data": [1.0, 500, 1500, "Home/home/news_detail/184-360"], "isController": false}, {"data": [1.0, 500, 1500, "Home/home-404"], "isController": false}, {"data": [0.34, 500, 1500, "Home/home-321"], "isController": false}, {"data": [0.98, 500, 1500, "Home/home/aboutus-322"], "isController": false}, {"data": [0.98, 500, 1500, "Home/home/pg_cc-324"], "isController": false}, {"data": [1.0, 500, 1500, "Home/home/mission_vision-347"], "isController": false}, {"data": [1.0, 500, 1500, "Home/home/award-348"], "isController": false}, {"data": [0.96, 500, 1500, "Home/home-323"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 550, 37, 6.7272727272727275, 27.89090909090912, 10, 168, 24.0, 44.0, 57.0, 90.96000000000004, 5.59244308418152, 27.955264586108374, 2.7897671954914744], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Home/home/news_detail/166-342", 50, 0, 0.0, 21.96, 11, 44, 21.0, 32.0, 37.34999999999999, 44.0, 0.510813930917524, 1.8826286867995465, 0.26039538275287843], "isController": false}, {"data": ["Home/home/ra-358", 50, 0, 0.0, 31.380000000000006, 20, 50, 30.0, 43.9, 46.0, 50.0, 0.5106887148007804, 2.4965895569264713, 0.25733923519258073], "isController": false}, {"data": ["Home/home/all_news-341", 50, 0, 0.0, 22.659999999999997, 12, 44, 20.5, 35.0, 40.34999999999999, 44.0, 0.5107356636499214, 1.4698613288831233, 0.25237524004576195], "isController": false}, {"data": ["Home/home/news_detail/184-360", 50, 0, 0.0, 22.66, 12, 46, 20.0, 34.9, 36.89999999999999, 46.0, 0.5106104858969384, 2.0793415294826496, 0.2597930304221728], "isController": false}, {"data": ["Home/home-404", 50, 0, 0.0, 27.26, 15, 48, 25.5, 40.8, 47.0, 48.0, 0.5104593112882972, 3.7367216771651135, 0.25971611443476844], "isController": false}, {"data": ["Home/home-321", 50, 33, 66.0, 64.1, 31, 168, 57.0, 92.6, 116.74999999999986, 168.0, 0.5099127029452558, 3.7332182949029127, 0.24549508061719835], "isController": false}, {"data": ["Home/home/aboutus-322", 50, 1, 2.0, 21.92, 10, 52, 19.0, 36.9, 41.599999999999966, 52.0, 0.5102613558664748, 3.332146178397575, 0.2516425631958689], "isController": false}, {"data": ["Home/home/pg_cc-324", 50, 1, 2.0, 22.180000000000003, 11, 51, 20.0, 35.9, 40.89999999999999, 51.0, 0.5106574203629753, 2.305438724939487, 0.2508405101978287], "isController": false}, {"data": ["Home/home/mission_vision-347", 50, 0, 0.0, 20.120000000000005, 10, 37, 19.0, 33.9, 35.449999999999996, 37.0, 0.5108609027933874, 1.5101327663628747, 0.2599204398001512], "isController": false}, {"data": ["Home/home/award-348", 50, 0, 0.0, 23.64, 12, 44, 21.0, 37.9, 40.449999999999996, 44.0, 0.5108034938958982, 1.7873133970986361, 0.25839473616999536], "isController": false}, {"data": ["Home/home-323", 50, 2, 4.0, 28.919999999999998, 16, 76, 27.0, 41.9, 49.749999999999936, 76.0, 0.5103498958886212, 3.735920722247173, 0.24570556511043973], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["The operation lasted too long: It took 63 milliseconds, but should not have lasted longer than 50 milliseconds.", 2, 5.405405405405405, 0.36363636363636365], "isController": false}, {"data": ["The operation lasted too long: It took 57 milliseconds, but should not have lasted longer than 50 milliseconds.", 2, 5.405405405405405, 0.36363636363636365], "isController": false}, {"data": ["The operation lasted too long: It took 54 milliseconds, but should not have lasted longer than 50 milliseconds.", 2, 5.405405405405405, 0.36363636363636365], "isController": false}, {"data": ["The operation lasted too long: It took 78 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, 2.7027027027027026, 0.18181818181818182], "isController": false}, {"data": ["The operation lasted too long: It took 81 milliseconds, but should not have lasted longer than 50 milliseconds.", 2, 5.405405405405405, 0.36363636363636365], "isController": false}, {"data": ["The operation lasted too long: It took 60 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, 2.7027027027027026, 0.18181818181818182], "isController": false}, {"data": ["The operation lasted too long: It took 66 milliseconds, but should not have lasted longer than 50 milliseconds.", 2, 5.405405405405405, 0.36363636363636365], "isController": false}, {"data": ["The operation lasted too long: It took 101 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, 2.7027027027027026, 0.18181818181818182], "isController": false}, {"data": ["The operation lasted too long: It took 51 milliseconds, but should not have lasted longer than 50 milliseconds.", 2, 5.405405405405405, 0.36363636363636365], "isController": false}, {"data": ["The operation lasted too long: It took 93 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, 2.7027027027027026, 0.18181818181818182], "isController": false}, {"data": ["The operation lasted too long: It took 53 milliseconds, but should not have lasted longer than 50 milliseconds.", 2, 5.405405405405405, 0.36363636363636365], "isController": false}, {"data": ["The operation lasted too long: It took 168 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, 2.7027027027027026, 0.18181818181818182], "isController": false}, {"data": ["The operation lasted too long: It took 136 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, 2.7027027027027026, 0.18181818181818182], "isController": false}, {"data": ["The operation lasted too long: It took 98 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, 2.7027027027027026, 0.18181818181818182], "isController": false}, {"data": ["The operation lasted too long: It took 89 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, 2.7027027027027026, 0.18181818181818182], "isController": false}, {"data": ["The operation lasted too long: It took 86 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, 2.7027027027027026, 0.18181818181818182], "isController": false}, {"data": ["The operation lasted too long: It took 56 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, 2.7027027027027026, 0.18181818181818182], "isController": false}, {"data": ["The operation lasted too long: It took 68 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, 2.7027027027027026, 0.18181818181818182], "isController": false}, {"data": ["The operation lasted too long: It took 77 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, 2.7027027027027026, 0.18181818181818182], "isController": false}, {"data": ["The operation lasted too long: It took 59 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, 2.7027027027027026, 0.18181818181818182], "isController": false}, {"data": ["The operation lasted too long: It took 88 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, 2.7027027027027026, 0.18181818181818182], "isController": false}, {"data": ["The operation lasted too long: It took 58 milliseconds, but should not have lasted longer than 50 milliseconds.", 2, 5.405405405405405, 0.36363636363636365], "isController": false}, {"data": ["The operation lasted too long: It took 52 milliseconds, but should not have lasted longer than 50 milliseconds.", 2, 5.405405405405405, 0.36363636363636365], "isController": false}, {"data": ["The operation lasted too long: It took 73 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, 2.7027027027027026, 0.18181818181818182], "isController": false}, {"data": ["The operation lasted too long: It took 85 milliseconds, but should not have lasted longer than 50 milliseconds.", 3, 8.108108108108109, 0.5454545454545454], "isController": false}, {"data": ["The operation lasted too long: It took 76 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, 2.7027027027027026, 0.18181818181818182], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 550, 37, "The operation lasted too long: It took 85 milliseconds, but should not have lasted longer than 50 milliseconds.", 3, "The operation lasted too long: It took 63 milliseconds, but should not have lasted longer than 50 milliseconds.", 2, "The operation lasted too long: It took 57 milliseconds, but should not have lasted longer than 50 milliseconds.", 2, "The operation lasted too long: It took 54 milliseconds, but should not have lasted longer than 50 milliseconds.", 2, "The operation lasted too long: It took 81 milliseconds, but should not have lasted longer than 50 milliseconds.", 2], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Home/home-321", 50, 33, "The operation lasted too long: It took 85 milliseconds, but should not have lasted longer than 50 milliseconds.", 3, "The operation lasted too long: It took 63 milliseconds, but should not have lasted longer than 50 milliseconds.", 2, "The operation lasted too long: It took 57 milliseconds, but should not have lasted longer than 50 milliseconds.", 2, "The operation lasted too long: It took 54 milliseconds, but should not have lasted longer than 50 milliseconds.", 2, "The operation lasted too long: It took 81 milliseconds, but should not have lasted longer than 50 milliseconds.", 2], "isController": false}, {"data": ["Home/home/aboutus-322", 50, 1, "The operation lasted too long: It took 52 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Home/home/pg_cc-324", 50, 1, "The operation lasted too long: It took 51 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Home/home-323", 50, 2, "The operation lasted too long: It took 58 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, "The operation lasted too long: It took 76 milliseconds, but should not have lasted longer than 50 milliseconds.", 1, "", "", "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});

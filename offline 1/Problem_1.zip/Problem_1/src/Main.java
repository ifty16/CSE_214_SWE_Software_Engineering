import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Package: ");
        String a= scanner.nextLine();
        System.out.print("Enter Internet: ");
        String b= scanner.nextLine();
        System.out.print("Enter Framework: ");
        String c= scanner.nextLine();
        Builder builder= new Builder();
        Packagee p= builder.getPackage(a,c,b);
        scanner.close();
    }
}

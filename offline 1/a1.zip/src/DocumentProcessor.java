public interface DocumentProcessor {

    public void LoadDocument();
    public void SaveDocument();
}

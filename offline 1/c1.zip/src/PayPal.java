public class PayPal implements Payment{
    @Override
    public void PaymentType() {
        System.out.println("Payment done by Paypal");
    }
}

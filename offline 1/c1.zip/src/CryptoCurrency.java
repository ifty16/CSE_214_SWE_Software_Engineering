public class CryptoCurrency implements Payment{
    @Override
    public void PaymentType() {
        System.out.println("Payment done by Crypto Currency");
    }
}

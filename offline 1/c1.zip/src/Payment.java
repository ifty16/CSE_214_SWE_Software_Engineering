public interface Payment {
    public void PaymentType();
}

public class CreditCard implements Payment{
    @Override
    public void PaymentType() {
        System.out.println("Payment done by Credit Card");
    }
}
